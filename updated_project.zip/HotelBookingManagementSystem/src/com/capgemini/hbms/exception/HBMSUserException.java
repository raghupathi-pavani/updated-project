package com.capgemini.hbms.exception;

public class HBMSUserException extends Exception {
	String msg;
	public HBMSUserException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
