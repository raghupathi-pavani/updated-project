package com.capgemini.hbms.exception;

public class HBMSEmployeeException extends Exception {
	String msg;
	public HBMSEmployeeException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
