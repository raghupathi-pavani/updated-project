package com.capgemini.hbms.exception;

public class HBMSException extends Exception{
	String msg;
	public HBMSException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
